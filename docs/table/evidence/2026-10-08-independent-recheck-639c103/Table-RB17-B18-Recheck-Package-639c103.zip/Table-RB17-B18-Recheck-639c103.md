# Table — RB17 correction and B18 delivery recheck

## Disposition

**The three findings from the independent review of `7220679` are resolved within this recheck's scope. No new blocking finding was established in the reviewed correction delta.** This closes that bounded correction request; it is not an independent certification of every application behavior or permission to deploy, connect a real retailer, or spend money.

The delivered recipe-reconciliation implementation addresses the original failure mechanisms rather than suppressing the tests. B18 has recorded Chromium coverage, with its actual testing limits kept explicit. The appropriate remaining release work is the already documented integration, nutrition-data, device, and hosting work—not a new open-ended polish assignment.

## 1. Source identity and integrity

| Item | Result independently established in this review |
|---|---|
| Uploaded bundle | `table-639c103.bundle` |
| SHA-256 | `73f03ec52cac968f55f7d23490a9d9fd4b204366668078d0c497e97876391df6`, matching the uploaded checksum |
| Delivered head | `639c103fc822f7567bdbf9092606328174bb0d6c` |
| Implementation commit | `abdd5a2cbd1014822ee09670b484eb528468ee22` |
| Prior reviewed head | `7220679d814c19e5611e324da1eb1b6a768e5964` |
| Connected GitHub read | `main` matched the delivered head when checked on 2026-10-08 |
| Restore | Plain clone and explicit `--branch main` clone both produced the expected checkout, with `init.defaultBranch=master` |
| Integrity | `git bundle verify` and `git fsck --full` completed successfully |
| Post-verification delta | Only `docs/**` and `CLAUDE.md`; no application code, tests, migrations, or executable verification scripts changed after the implementation commit |
| Independently recomputed tracked-file hash at implementation commit | `2b5f21da599021eff1b611ff55712209bb0884e2e74af51109595d8e54073a6a`, matching the run's recorded before/after hash |

The hash was recomputed using the repository verifier's `git ls-files -z | xargs -0 sha256sum | sha256sum` algorithm in an isolated checkout of the implementation commit. It is an identity check against the supplied record, not proof that this reviewer watched the original run execute.

## 2. Recorded verification versus new execution

### Claude's saved evidence, independently inspected

The structured records in `docs/table/evidence/2026-10-08-verify-abdd5a2/` contain:

| Evidence | Inspected result |
|---|---|
| `vitest.json` | 141 total, 141 passed, zero failed/pending/todo; all 141 individual assertion results also report passed |
| `playwright.json` | 104 expected, zero unexpected/flaky/skipped; all 104 individual test records agree |
| `mutation/results.json` | 39 KILLED, zero SURVIVED/ERROR; restored true, tied to the implementation commit |
| `summary.md` | Typecheck, production build, mutation self-test, and the suites above report PASS |

These are **contents of the delivered evidence**, not a new full-suite run by this reviewer. The inspected source delta, test changes, and correction tests are consistent with that evidence. Previously disclosed test changes are necessary consequences of requiring a version and replacing whole-draft acknowledgement with explicit field decisions; this review found no reason to reinstate the old bypass assertion.

### Execution performed here

`recheck.cjs` executes the supplied TypeScript using the installed TypeScript transpiler. It does not install the application, run React, render a DOM, provision PostgreSQL, or contact a retailer.

- Replayed the repository's 19 pure recipe-rebase unit cases with a small Node-assert adapter: **19 passed, 0 failed**. This is deliberately not labeled a Vitest run. The assertions and delivered pure functions execute; suite/expect wrappers are replaced locally.
- Executed three independently written source-level checks for untouched methods/metadata, subsequent-version conflict behavior, and repeated ingredient rows: **3 passed**.
- Exercised the actual `saveRecipeVersionCommand` callback with a recording SQL double: **9 expected outcomes observed**. Seven missing/malformed/stale expectations were refused before any recorded SQL write; a valid current expectation and new-recipe creation succeeded.
- Executed the real `normalizeUnit` function extracted from its source. Unrelated decimal arithmetic was neither substituted nor exercised.

This environment had no project dependencies installed and no PostgreSQL executable available on PATH. No dependency downloads or database provisioning were performed. Therefore the full PostgreSQL, production-build, Chromium, mutation, and device suites were **not independently rerun** here.

## 3. Finding-by-finding recheck

### RB17-01 — content-visible reconciliation and untouched metadata

**Disposition: resolved for the original failure cases, supported by source execution and the recorded browser/integration evidence.**

`src/domain/recipes/rebase.ts` now performs a three-way field comparison against the draft's base version. Fields untouched locally take the newer saved value. Fields changed differently by both people remain pending until an explicit decision. The editor renders both full field values rather than merely saying that instructions changed.

The independent probe changed only the local title while the incoming version changed steps, reheat instructions, summary, source label, ingredient form, and ingredient note. The local title survived, every incoming untouched value survived, and the generated change descriptions contained the actual incoming text. The old hidden-field and method overwrite counterexamples no longer reproduce at the pure reconciliation boundary.

A second probe established that an unresolved title conflict survives a later incoming version that changes only instructions; deciding the title keeps those instructions; another incoming title change reopens the title conflict. An older incoming version is ignored by the rebase reducer.

Source inspected: `src/domain/recipes/rebase.ts` and `src/ui/RecipeEditor.tsx`, including the pending-field Save guard, the full-content conflict display, the reducer-based edits, and the new browser cases. This review did not independently render the editor or test every possible interaction race.

### RB17-02 — repeated ingredient rows

**Disposition: resolved for the original lost-occurrence case.**

The difference calculation now counts occurrences instead of retaining only the last component/ingredient pair. The independent probe changed the first of two rice occurrences from 10 to 20 grams while the second remained 100 grams. The diff reported the removed 10-gram occurrence and added 20-gram occurrence, and the merged draft retained separate quantities `[20, 100]`.

The replayed unit cases additionally cover multiplicity, addition/removal, reorder, forms, notes, units, identity versus display-name changes, and equivalent saved representations. The recorded integration case establishes separate stored ingredient rows; that database case was not rerun here.

### RB17-03 — mandatory expected version

**Disposition: resolved at the inspected server-command admission boundary.**

`src/server/commands/library.ts` now refuses ordinary edits of an existing recipe without a valid `expectedVersionNo`. The independent callback probe supplied an existing recipe whose current version is 2:

| Request | Observed result | Recorded SQL writes |
|---|---|---:|
| Expectation omitted | `version_required` | 0 |
| Expectation null | `version_required` | 0 |
| String `"2"` | `invalid` | 0 |
| Zero | `invalid` | 0 |
| Fraction `1.5` | `invalid` | 0 |
| Older version 1 | `stale_version` | 0 |
| Future version 3 | `stale_version` | 0 |
| Current version 2 | Accepted as version 3 | 5 |
| New recipe, no expectation | Accepted as version 1 | 6 |

These write counts belong to the recording SQL callback double, not a live database. They demonstrate that the prior optional-check branch is gone. The delivered integration tests separately inspect recipe versions, the current-version pointer, and ingredient-row counts for rejected commands.

## 4. B18 assessment

The B18 source and recorded test coverage address cross-screen layout at 320 CSS pixels with 150% and 200% root-font scaling. The inspected tests measure actual font sizes, page/dialog overflow, keyboard traversal, focus, and whether controls are covered. The shared-modal change accounts for radio groups at Tab boundaries; header/nav metrics drive layout padding, and excessively tall sticky bars become non-sticky.

The package records 16 broad sweep cases and 4 recipe-editor scaling cases, within the 104-test browser run. The implementation is not merely shrinking text or changing a screenshot assertion to make the reported cases pass.

**Limits remain:** this is recorded Chromium automation using injected root-font scaling. It is not an independently rerun browser sweep, physical iPhone validation, Safari/WebKit validation, native system text-size validation, VoiceOver testing, or a blanket accessibility-conformance certification. No new B18 blocker was established in this focused source/evidence inspection.

## 5. What remains before the requested household tool is delivered

The repository's own backlog distinguishes the remaining work:

| Workstream | Documented remaining requirement |
|---|---|
| B5/B6 — Kroger | Adapter work and verification with authorized credentials; account/store setup; separate explicit approval for a real cart addition. Pickup and order submission remain a checkout handoff under the current scope. |
| B7 — nutrition data | FoodData Central lookup integration, API key, provenance, and explicit ingredient-match confirmation. Unmatched values must remain unknown. |
| B8 — devices | WebKit/Safari, actual phones, and VoiceOver validation; these are not supplied by Chromium test results. |
| B9 — deployment | A chosen private hosting arrangement, database, secrets, HTTPS, backups, and approval to provision/deploy. |

These are documented project dependencies, not a claim that all preparatory code universally requires live credentials. The key distinction is that no tested live integration or deployed household service exists yet. This review does not select a host, approve an account connection, or grant spending authority.

The defensible status is: **the bounded recipe corrections are closed; the simulated-retailer implementation has recorded Chromium verification; live household release remains gated by integration, data, devices, and deployment.**

## 6. Review boundary and files

No remote writes, implementation edits, new migrations, retailer operations, or deployment were performed. The original attachments were not changed. Local clones and review artifacts were created only under `/mnt/data/table-review-639c103/`.

Included review evidence: `recheck.cjs`, its executed JSON results, identity/restore logs, the recomputed tracked-file hash, the post-verification changed-file list, and parsed verification facts. Run the probe with Node and an installed TypeScript package, supplying `TYPESCRIPT_PATH` when needed:

```bash
TYPESCRIPT_PATH=/path/to/typescript node recheck.cjs /path/to/table
```

No new implementation prompt is needed to repeat or reopen these three corrected findings.
