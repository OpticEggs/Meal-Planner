// Read-only source-level recheck of RB17-01..03, not a browser/PostgreSQL run.
const fs=require('node:fs'), path=require('node:path'), vm=require('node:vm'), assert=require('node:assert/strict');
const root=path.resolve(process.argv[2] || path.join(__dirname,'repo'));
const ts=require(process.env.TYPESCRIPT_PATH || '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
function compile(source,file,deps={}) {
 const {outputText}=ts.transpileModule(source,{fileName:file,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}});
 const m={exports:{}}; const req=id=>{if(id in deps)return deps[id]; if(id.startsWith('node:'))return require(id); throw Error('Unconfigured dependency '+id);};
 vm.runInThisContext('(function(module,exports,require){'+outputText+'\n})',{filename:file})(m,m.exports,req); return m.exports;
}
const source=f=>fs.readFileSync(path.join(root,f),'utf8');
// Execute normalizeUnit's actual function body; no arithmetic stubs or dependency download.
const unitFile=ts.createSourceFile('units.ts',source('src/domain/units.ts'),ts.ScriptTarget.Latest,true);
const norm=unitFile.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='normalizeUnit');
assert.ok(norm); const units=compile(norm.getText(unitFile),'normalizeUnit.ts');
const re=compile(source('src/domain/recipes/rebase.ts'),'src/domain/recipes/rebase.ts',{'@/domain/units':units});
const result={evidenceType:'Actual delivered pure TypeScript execution plus a recording SQL callback double. Repository unit tests replayed through Node assert, NOT Vitest, React, DOM, PostgreSQL or browser verification.',testReplay:[],probes:[]};
const stack=[];function expect(v){return {toBe:x=>assert.strictEqual(v,x),toEqual:x=>assert.deepStrictEqual(v,x),toMatchObject:x=>subset(v,x)};}
function subset(a,b){for(const k of Object.keys(b)){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k]))subset(a[k],b[k]);else assert.deepStrictEqual(a[k],b[k]);}}
const suite={describe:(name,fn)=>{stack.push(name);try{fn();}finally{stack.pop();}},it:(name,fn)=>{try{fn();result.testReplay.push({name:[...stack,name].join(' / '),status:'PASS'});}catch(e){result.testReplay.push({name,status:'FAIL',error:e.message});}},expect};
compile(source('tests/unit/recipe-rebase.test.ts'),'tests/unit/recipe-rebase.test.ts',{'vitest':suite,'@/domain/recipes/rebase':re});
const base={title:'Rice bowl',cuisine:'Household',minutes:'20',level:'easy',leftovers:true,instructions:'Old method.',reheat:'Old reheat.',summary:'Old summary',sourceLabel:'Old source',components:[{key:'main',name:'Main'}],rows:[{componentKey:'main',ingredientName:'Rice',ingredientKey:'rice',quantity:'100',unit:'g',form:'raw',note:'Old note'}]};
function probe(id,fn){try{const detail=fn();result.probes.push({id,status:'PASS',detail});}catch(e){result.probes.push({id,status:'FAIL',error:e.message});}}
probe('RB17-01 untouched methods and hidden metadata',()=>{
 const current={...structuredClone(base),instructions:'Alex new method',reheat:'Alex new reheat',summary:'Alex new summary',sourceLabel:'Alex new source',rows:[{...base.rows[0],form:'cooked',note:'Alex new note'}]};
 const {merged,taken,conflicts}=re.rebase(base,current,{...base,title:"Jon's title"});
 assert.deepStrictEqual(conflicts,[]); assert.equal(merged.title,"Jon's title");
 for(const k of ['instructions','reheat','summary','sourceLabel'])assert.equal(merged[k],current[k]);
 assert.deepStrictEqual(merged.rows,current.rows);
 const changes=re.fieldChanges(base,current);assert.ok(changes.find(c=>c.key==='instructions').to.includes('Alex new method'));
 assert.ok(changes.find(c=>c.key==='ingredients').details.some(x=>x.includes('Alex new note')));
 return {taken,changes};
});
probe('RB17-01 unresolved decisions survive later versions and explicit choice preserves unrelated fields',()=>{
 let s=re.editorInit(base,1);s=re.editorReducer(s,{type:'edit',fn:f=>({...f,title:'Jon title'})});
 s=re.editorReducer(s,{type:'rebase',cur:{...base,title:'Alex title'},version:2,by:'Alex',title:'Alex title'});assert.deepStrictEqual(s.pending,['title']);
 s=re.editorReducer(s,{type:'rebase',cur:{...base,title:'Alex title',instructions:'v3 method'},version:3,by:'Alex',title:'Alex title'});assert.deepStrictEqual(s.pending,['title']);
 s=re.editorReducer(s,{type:'decide',k:'title',choice:'mine'}); assert.deepStrictEqual(s.pending,[]);assert.equal(s.f.title,'Jon title'); assert.equal(s.f.instructions,'v3 method');
 s=re.editorReducer(s,{type:'rebase',cur:{...base,title:'Alex v4 title',instructions:'v3 method'},version:4,by:'Alex',title:'Alex v4 title'});assert.deepStrictEqual(s.pending,['title']);
 const old=s;s=re.editorReducer(s,{type:'rebase',cur:base,version:2,by:'Alex',title:'Late old version'});assert.strictEqual(s,old);
 return {seen:s.seen,pending:s.pending};
});
probe('RB17-02 first repeated occurrence quantity is retained in diff and draft',()=>{
 const from={...base,rows:[{...base.rows[0],quantity:'10'},{...base.rows[0],quantity:'100'}]};const to={...from,rows:[{...from.rows[0],quantity:'20'},from.rows[1]]};
 const diff=re.ingredientChanges(from,to);assert.ok(diff.some(t=>t.includes('10 g')));assert.ok(diff.some(t=>t.includes('20 g')));
 const {merged}=re.rebase(from,to,{...from,title:'Local title'});assert.deepStrictEqual(merged.rows.map(r=>r.quantity),['20','100']);return {diff};
});
async function commandCase(expected,isNew=false){const writes=[];const db={query:async(sql,args)=>{
 if(/SELECT id, current_version_id FROM recipes/.test(sql))return{rowCount:1,rows:[{id:'recipe-1',current_version_id:'version-2'}]};
 if(/SELECT max\(version_no\)/.test(sql))return{rowCount:1,rows:[{n:2}]};
 if(/SELECT v.title, m.display_name/.test(sql))return{rowCount:1,rows:[{title:'Alex version 2',display_name:'Alex'}]};
 if(/^(INSERT|UPDATE)/.test(sql.trim())){writes.push({sql,args});return{rowCount:1,rows:[]};}throw Error('Unmocked SQL: '+sql);
 }};class Reject extends Error{constructor(code,message,details){super(message);this.code=code;this.details=details;}}
 const library=compile(source('src/server/commands/library.ts'),'src/server/commands/library.ts',{'./framework':{Reject,runCommand:async(a,n,i,p,fn)=>{try{return await fn(db);}catch(e){if(e instanceof Reject)return{status:'rejected',code:e.code};throw e;}}},'@/domain/units':units,'@/domain/recipes/rebase':re});
 const draft={recipeId:isNew?null:'recipe-1',title:'Old offline draft',instructions:'Old method.',components:[{key:'main',name:'Main'}],ingredients:[{componentKey:'main',ingredientKey:'rice',ingredientName:'Rice',quantity:'100',unit:'g'}],...(expected===undefined?{}:{expectedVersionNo:expected})};
 const r=await library.saveRecipeVersionCommand({householdId:'hh',memberId:'jon',displayName:'Jon'},'probe-op',draft);
 return{expected:expected===undefined?'(omitted)':expected,newRecipe:isNew,status:r.status,code:r.code??null,versionNo:r.result?.versionNo??null,sqlWrites:writes.length};}
(async()=>{
 result.serverCases=[];for(const [expected,code]of [[undefined,'version_required'],[null,'version_required'],['2','invalid'],[0,'invalid'],[1.5,'invalid'],[1,'stale_version'],[3,'stale_version']]){
 const r=await commandCase(expected);assert.equal(r.status,'rejected');assert.equal(r.code,code);assert.equal(r.sqlWrites,0);result.serverCases.push(r);}
 for(const [expected,isNew,version]of [[2,false,3],[undefined,true,1]]){const r=await commandCase(expected,isNew);assert.equal(r.status,'accepted');assert.equal(r.versionNo,version);assert.ok(r.sqlWrites>0);result.serverCases.push(r);}
 result.testReplayCounts={passed:result.testReplay.filter(x=>x.status==='PASS').length,failed:result.testReplay.filter(x=>x.status!=='PASS').length};
 console.log(JSON.stringify(result,null,2));if(result.testReplayCounts.failed||result.probes.some(x=>x.status!=='PASS'))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
